
import { PrismaClient } from '@prisma/client'
import bcrypt from 'bcryptjs'
import { DEFAULT_CATEGORIES } from '../lib/types'

const prisma = new PrismaClient()

async function main() {
  console.log('🌱 Starting database seed...')

  // Create categories
  console.log('📦 Creating categories...')
  for (const categoryData of DEFAULT_CATEGORIES) {
    const existingCategory = await prisma.category.findUnique({
      where: { name: categoryData.name }
    })

    if (!existingCategory) {
      await prisma.category.create({
        data: {
          name: categoryData.name,
          color: categoryData.color,
          icon: categoryData.icon,
          description: categoryData.description,
        }
      })
      console.log(`✅ Created category: ${categoryData.name}`)
    } else {
      console.log(`⏭️  Category already exists: ${categoryData.name}`)
    }
  }

  // Create demo user
  console.log('👤 Creating demo user...')
  const demoEmail = 'john@doe.com'
  const demoPassword = 'johndoe123'

  const existingUser = await prisma.user.findUnique({
    where: { email: demoEmail }
  })

  if (!existingUser) {
    const hashedPassword = await bcrypt.hash(demoPassword, 12)
    
    const demoUser = await prisma.user.create({
      data: {
        name: 'John Doe',
        email: demoEmail,
        password: hashedPassword,
        notificationsEnabled: true,
        publicProfile: true,
      }
    })

    console.log(`✅ Created demo user: ${demoEmail}`)

    // Create some sample habits for the demo user
    console.log('🎯 Creating sample habits for demo user...')
    
    const categories = await prisma.category.findMany()
    const healthCategory = categories.find(c => c.name === 'Health')
    const learningCategory = categories.find(c => c.name === 'Learning')
    const fitnessCategory = categories.find(c => c.name === 'Fitness')

    if (healthCategory) {
      await prisma.habit.create({
        data: {
          title: 'Drink 8 glasses of water',
          description: 'Stay hydrated throughout the day',
          userId: demoUser.id,
          categoryId: healthCategory.id,
          targetDays: ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'],
        }
      })
      console.log('✅ Created sample habit: Drink water')
    }

    if (learningCategory) {
      await prisma.habit.create({
        data: {
          title: 'Read for 30 minutes',
          description: 'Read books, articles, or learning materials',
          userId: demoUser.id,
          categoryId: learningCategory.id,
          targetDays: ['monday', 'tuesday', 'wednesday', 'thursday', 'friday'],
        }
      })
      console.log('✅ Created sample habit: Reading')
    }

    if (fitnessCategory) {
      await prisma.habit.create({
        data: {
          title: 'Morning workout',
          description: '30-minute exercise routine',
          userId: demoUser.id,
          categoryId: fitnessCategory.id,
          targetDays: ['monday', 'wednesday', 'friday'],
        }
      })
      console.log('✅ Created sample habit: Workout')
    }

    // Create some sample completions for the past few days
    console.log('📊 Creating sample completions...')
    const habits = await prisma.habit.findMany({
      where: { userId: demoUser.id }
    })

    const today = new Date()
    for (let i = 0; i < 7; i++) {
      const date = new Date(today)
      date.setDate(today.getDate() - i)
      date.setHours(0, 0, 0, 0)

      // Randomly complete some habits for each day
      for (const habit of habits) {
        if (Math.random() > 0.3) { // 70% chance of completion
          try {
            await prisma.habitCompletion.create({
              data: {
                habitId: habit.id,
                userId: demoUser.id,
                date: date,
              }
            })
          } catch (error) {
            // Ignore duplicate completion errors
          }
        }
      }
    }
    console.log('✅ Created sample completions')

  } else {
    console.log(`⏭️  Demo user already exists: ${demoEmail}`)
  }

  console.log('🎉 Database seed completed!')
  console.log(`\n📝 Demo Account:`)
  console.log(`   Email: ${demoEmail}`)
  console.log(`   Password: ${demoPassword}`)
}

main()
  .catch((e) => {
    console.error('❌ Error during seed:', e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
