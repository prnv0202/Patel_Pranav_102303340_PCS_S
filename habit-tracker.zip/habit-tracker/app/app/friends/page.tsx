
import { getServerSession } from 'next-auth'
import { redirect } from 'next/navigation'
import { FriendsClient } from './friends-client'

export default async function FriendsPage() {
  const session = await getServerSession()

  if (!session) {
    redirect('/')
  }

  return <FriendsClient />
}
