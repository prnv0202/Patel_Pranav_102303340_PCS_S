
'use client'

import { useEffect, useState } from 'react'
import { Header } from '@/components/layout/header'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { useToast } from '@/hooks/use-toast'
import { 
  Users, 
  UserPlus, 
  Check, 
  X, 
  Search,
  Mail,
  Calendar,
  UserCheck,
  UserX
} from 'lucide-react'

interface Friend {
  id: string
  friend: {
    id: string
    name: string
    email: string
    image: string | null
    publicProfile: boolean
  }
  createdAt: string
}

interface FriendRequest {
  id: string
  status: string
  createdAt: string
  requester?: {
    id: string
    name: string
    email: string
    image: string | null
  }
  receiver?: {
    id: string
    name: string
    email: string
    image: string | null
  }
}

export function FriendsClient() {
  const [friends, setFriends] = useState<Friend[]>([])
  const [incomingRequests, setIncomingRequests] = useState<FriendRequest[]>([])
  const [outgoingRequests, setOutgoingRequests] = useState<FriendRequest[]>([])
  const [friendEmail, setFriendEmail] = useState('')
  const [loading, setLoading] = useState(true)
  const [sendingRequest, setSendingRequest] = useState(false)
  const { toast } = useToast()

  useEffect(() => {
    fetchFriendsData()
  }, [])

  const fetchFriendsData = async () => {
    try {
      const [friendsResponse, requestsResponse] = await Promise.all([
        fetch('/api/friends'),
        fetch('/api/friends/requests'),
      ])

      if (friendsResponse.ok) {
        const friendsData = await friendsResponse.json()
        setFriends(friendsData)
      }

      if (requestsResponse.ok) {
        const requestsData = await requestsResponse.json()
        setIncomingRequests(requestsData.incoming)
        setOutgoingRequests(requestsData.outgoing)
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to load friends data',
        variant: 'destructive',
      })
    } finally {
      setLoading(false)
    }
  }

  const handleSendRequest = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!friendEmail.trim()) return

    setSendingRequest(true)
    try {
      const response = await fetch('/api/friends', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ friendEmail: friendEmail.trim() }),
      })

      if (response.ok) {
        toast({
          title: 'Friend request sent',
          description: `Request sent to ${friendEmail}`,
        })
        setFriendEmail('')
        fetchFriendsData()
      } else {
        const error = await response.json()
        toast({
          title: 'Error',
          description: error.message,
          variant: 'destructive',
        })
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to send friend request',
        variant: 'destructive',
      })
    } finally {
      setSendingRequest(false)
    }
  }

  const handleRequestAction = async (requestId: string, action: 'accept' | 'reject') => {
    try {
      const response = await fetch(`/api/friends/requests/${requestId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ action }),
      })

      if (response.ok) {
        toast({
          title: action === 'accept' ? 'Friend request accepted' : 'Friend request rejected',
          description: action === 'accept' ? 'You are now friends!' : 'Request has been rejected',
        })
        fetchFriendsData()
      } else {
        throw new Error('Failed to update request')
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to update friend request',
        variant: 'destructive',
      })
    }
  }

  const handleCancelRequest = async (requestId: string) => {
    try {
      const response = await fetch(`/api/friends/requests/${requestId}`, {
        method: 'DELETE',
      })

      if (response.ok) {
        toast({
          title: 'Request cancelled',
          description: 'Friend request has been cancelled',
        })
        fetchFriendsData()
      } else {
        throw new Error('Failed to cancel request')
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to cancel friend request',
        variant: 'destructive',
      })
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container mx-auto px-4 py-8 max-w-4xl">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-muted rounded w-48"></div>
            <div className="h-64 bg-muted rounded"></div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2 flex items-center space-x-3">
            <Users className="h-8 w-8 text-primary" />
            <span>Friends</span>
          </h1>
          <p className="text-muted-foreground">
            Connect with friends and share your habit journey.
          </p>
        </div>

        <Tabs defaultValue="friends" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="friends" className="flex items-center space-x-2">
              <Users className="h-4 w-4" />
              <span>My Friends ({friends.length})</span>
            </TabsTrigger>
            <TabsTrigger value="requests" className="flex items-center space-x-2">
              <UserPlus className="h-4 w-4" />
              <span>Requests ({incomingRequests.length})</span>
            </TabsTrigger>
            <TabsTrigger value="find" className="flex items-center space-x-2">
              <Search className="h-4 w-4" />
              <span>Find Friends</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="friends">
            <Card>
              <CardHeader>
                <CardTitle>My Friends</CardTitle>
              </CardHeader>
              <CardContent>
                {friends.length === 0 ? (
                  <div className="text-center py-8">
                    <Users className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                    <p className="text-muted-foreground">No friends yet</p>
                    <p className="text-sm text-muted-foreground mt-1">
                      Send friend requests to connect with others!
                    </p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {friends.map((friendship) => (
                      <div
                        key={friendship.id}
                        className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors"
                      >
                        <div className="flex items-center space-x-3">
                          <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                            <Users className="h-5 w-5 text-primary" />
                          </div>
                          <div>
                            <p className="font-medium">{friendship.friend.name}</p>
                            <p className="text-sm text-muted-foreground">{friendship.friend.email}</p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                          <Calendar className="h-4 w-4" />
                          <span>
                            Friends since {new Date(friendship.createdAt).toLocaleDateString()}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="requests">
            <div className="space-y-6">
              {/* Incoming Requests */}
              <Card>
                <CardHeader>
                  <CardTitle>Incoming Requests</CardTitle>
                </CardHeader>
                <CardContent>
                  {incomingRequests.length === 0 ? (
                    <div className="text-center py-8">
                      <UserPlus className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                      <p className="text-muted-foreground">No incoming requests</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {incomingRequests.map((request) => (
                        <div
                          key={request.id}
                          className="flex items-center justify-between p-4 border rounded-lg"
                        >
                          <div className="flex items-center space-x-3">
                            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                              <UserPlus className="h-5 w-5 text-primary" />
                            </div>
                            <div>
                              <p className="font-medium">{request.requester?.name}</p>
                              <p className="text-sm text-muted-foreground">
                                {request.requester?.email}
                              </p>
                            </div>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Button
                              size="sm"
                              onClick={() => handleRequestAction(request.id, 'accept')}
                              className="flex items-center space-x-1"
                            >
                              <Check className="h-4 w-4" />
                              <span>Accept</span>
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleRequestAction(request.id, 'reject')}
                              className="flex items-center space-x-1"
                            >
                              <X className="h-4 w-4" />
                              <span>Reject</span>
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Outgoing Requests */}
              <Card>
                <CardHeader>
                  <CardTitle>Sent Requests</CardTitle>
                </CardHeader>
                <CardContent>
                  {outgoingRequests.length === 0 ? (
                    <div className="text-center py-8">
                      <Mail className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                      <p className="text-muted-foreground">No sent requests</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {outgoingRequests.map((request) => (
                        <div
                          key={request.id}
                          className="flex items-center justify-between p-4 border rounded-lg"
                        >
                          <div className="flex items-center space-x-3">
                            <div className="w-10 h-10 rounded-full bg-orange-100 dark:bg-orange-900/20 flex items-center justify-center">
                              <Mail className="h-5 w-5 text-orange-600" />
                            </div>
                            <div>
                              <p className="font-medium">{request.receiver?.name}</p>
                              <p className="text-sm text-muted-foreground">
                                {request.receiver?.email}
                              </p>
                            </div>
                          </div>
                          <div className="flex items-center space-x-2">
                            <span className="text-sm text-muted-foreground">Pending</span>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleCancelRequest(request.id)}
                              className="flex items-center space-x-1"
                            >
                              <X className="h-4 w-4" />
                              <span>Cancel</span>
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="find">
            <Card>
              <CardHeader>
                <CardTitle>Find Friends</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSendRequest} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="friendEmail">Friend's Email Address</Label>
                    <Input
                      id="friendEmail"
                      type="email"
                      placeholder="Enter your friend's email"
                      value={friendEmail}
                      onChange={(e) => setFriendEmail(e.target.value)}
                      required
                    />
                  </div>
                  <Button type="submit" disabled={sendingRequest} className="flex items-center space-x-2">
                    {sendingRequest ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                        <span>Sending...</span>
                      </>
                    ) : (
                      <>
                        <UserPlus className="h-4 w-4" />
                        <span>Send Friend Request</span>
                      </>
                    )}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
