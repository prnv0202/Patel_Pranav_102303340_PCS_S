
export const dynamic = "force-dynamic";

import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { prisma } from '@/lib/db'
import { getStartOfDay } from '@/lib/utils'

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession()
    
    if (!session?.user?.email) {
      return NextResponse.json({ message: 'Unauthorized' }, { status: 401 })
    }

    const user = await prisma.user.findUnique({
      where: { email: session.user.email },
    })

    if (!user) {
      return NextResponse.json({ message: 'User not found' }, { status: 404 })
    }

    const { date, notes } = await request.json()
    const completionDate = date ? new Date(date) : new Date()
    const completionDateStart = getStartOfDay(completionDate)

    const habit = await prisma.habit.findFirst({
      where: { 
        id: params.id,
        userId: user.id,
      },
    })

    if (!habit) {
      return NextResponse.json({ message: 'Habit not found' }, { status: 404 })
    }

    // Check if already completed for this date
    const existingCompletion = await prisma.habitCompletion.findFirst({
      where: {
        habitId: params.id,
        userId: user.id,
        date: completionDateStart,
      },
    })

    if (existingCompletion) {
      return NextResponse.json(
        { message: 'Habit already completed for this date' },
        { status: 400 }
      )
    }

    const completion = await prisma.habitCompletion.create({
      data: {
        habitId: params.id,
        userId: user.id,
        date: completionDateStart,
        notes: notes || null,
      },
    })

    return NextResponse.json(completion, { status: 201 })
  } catch (error) {
    console.error('Error completing habit:', error)
    return NextResponse.json(
      { message: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession()
    
    if (!session?.user?.email) {
      return NextResponse.json({ message: 'Unauthorized' }, { status: 401 })
    }

    const user = await prisma.user.findUnique({
      where: { email: session.user.email },
    })

    if (!user) {
      return NextResponse.json({ message: 'User not found' }, { status: 404 })
    }

    const { date } = await request.json()
    const completionDate = date ? new Date(date) : new Date()
    const completionDateStart = getStartOfDay(completionDate)

    const habit = await prisma.habit.findFirst({
      where: { 
        id: params.id,
        userId: user.id,
      },
    })

    if (!habit) {
      return NextResponse.json({ message: 'Habit not found' }, { status: 404 })
    }

    const completion = await prisma.habitCompletion.findFirst({
      where: {
        habitId: params.id,
        userId: user.id,
        date: completionDateStart,
      },
    })

    if (!completion) {
      return NextResponse.json(
        { message: 'Completion not found' },
        { status: 404 }
      )
    }

    await prisma.habitCompletion.delete({
      where: { id: completion.id },
    })

    return NextResponse.json({ message: 'Completion removed successfully' })
  } catch (error) {
    console.error('Error removing completion:', error)
    return NextResponse.json(
      { message: 'Internal server error' },
      { status: 500 }
    )
  }
}
