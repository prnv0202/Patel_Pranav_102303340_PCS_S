
export const dynamic = "force-dynamic";

import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { prisma } from '@/lib/db'
import { calculateStreak, calculateLongestStreak, calculateCompletionRate, getStartOfDay, getDayOfWeek } from '@/lib/utils'

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession()
    
    if (!session?.user?.email) {
      return NextResponse.json({ message: 'Unauthorized' }, { status: 401 })
    }

    const user = await prisma.user.findUnique({
      where: { email: session.user.email },
    })

    if (!user) {
      return NextResponse.json({ message: 'User not found' }, { status: 404 })
    }

    const habits = await prisma.habit.findMany({
      where: { 
        userId: user.id,
        isActive: true,
      },
      include: {
        category: true,
        completions: {
          orderBy: { date: 'desc' },
        },
        _count: {
          select: { completions: true },
        },
      },
      orderBy: { createdAt: 'desc' },
    })

    const today = getStartOfDay()
    const todayDayOfWeek = getDayOfWeek(new Date())

    const habitsWithStats = habits.map(habit => {
      const completionDates = habit.completions.map(c => c.date)
      const currentStreak = calculateStreak(completionDates)
      const longestStreak = calculateLongestStreak(completionDates)
      const completionRate = calculateCompletionRate(completionDates, habit.createdAt)
      const isCompletedToday = habit.completions.some(
        completion => getStartOfDay(completion.date).getTime() === today.getTime()
      )
      const shouldShowToday = habit.targetDays.includes(todayDayOfWeek)

      return {
        ...habit,
        currentStreak,
        longestStreak,
        completionRate,
        isCompletedToday,
        shouldShowToday,
        totalCompletions: habit._count.completions,
      }
    })

    return NextResponse.json(habitsWithStats)
  } catch (error) {
    console.error('Error fetching habits:', error)
    return NextResponse.json(
      { message: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession()
    
    if (!session?.user?.email) {
      return NextResponse.json({ message: 'Unauthorized' }, { status: 401 })
    }

    const user = await prisma.user.findUnique({
      where: { email: session.user.email },
    })

    if (!user) {
      return NextResponse.json({ message: 'User not found' }, { status: 404 })
    }

    const { title, description, categoryId, targetDays } = await request.json()

    if (!title || !categoryId || !targetDays || targetDays.length === 0) {
      return NextResponse.json(
        { message: 'Missing required fields' },
        { status: 400 }
      )
    }

    const habit = await prisma.habit.create({
      data: {
        title,
        description: description || null,
        userId: user.id,
        categoryId,
        targetDays,
      },
      include: {
        category: true,
        _count: {
          select: { completions: true },
        },
      },
    })

    return NextResponse.json({
      ...habit,
      currentStreak: 0,
      longestStreak: 0,
      completionRate: 0,
      isCompletedToday: false,
      totalCompletions: 0,
    }, { status: 201 })
  } catch (error) {
    console.error('Error creating habit:', error)
    return NextResponse.json(
      { message: 'Internal server error' },
      { status: 500 }
    )
  }
}
