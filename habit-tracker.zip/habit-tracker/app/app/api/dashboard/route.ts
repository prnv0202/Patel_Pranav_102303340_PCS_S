
export const dynamic = "force-dynamic";

import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { prisma } from '@/lib/db'
import { calculateStreak, calculateLongestStreak, calculateCompletionRate, getStartOfDay, getDaysAgo, getDayOfWeek } from '@/lib/utils'

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession()
    
    if (!session?.user?.email) {
      return NextResponse.json({ message: 'Unauthorized' }, { status: 401 })
    }

    const user = await prisma.user.findUnique({
      where: { email: session.user.email },
    })

    if (!user) {
      return NextResponse.json({ message: 'User not found' }, { status: 404 })
    }

    // Get all active habits with completions
    const habits = await prisma.habit.findMany({
      where: { 
        userId: user.id,
        isActive: true,
      },
      include: {
        category: true,
        completions: {
          orderBy: { date: 'desc' },
        },
        _count: {
          select: { completions: true },
        },
      },
      orderBy: { createdAt: 'desc' },
    })

    const today = getStartOfDay()
    const todayDayOfWeek = getDayOfWeek(new Date())

    // Calculate habits with stats
    const habitsWithStats = habits.map(habit => {
      const completionDates = habit.completions.map(c => c.date)
      const currentStreak = calculateStreak(completionDates)
      const longestStreak = calculateLongestStreak(completionDates)
      const completionRate = calculateCompletionRate(completionDates, habit.createdAt)
      const isCompletedToday = habit.completions.some(
        completion => getStartOfDay(completion.date).getTime() === today.getTime()
      )
      const shouldShowToday = habit.targetDays.includes(todayDayOfWeek)

      return {
        ...habit,
        currentStreak,
        longestStreak,
        completionRate,
        isCompletedToday,
        shouldShowToday,
        totalCompletions: habit._count.completions,
      }
    })

    // Calculate overall stats
    const totalHabits = habits.length
    const habitsForToday = habitsWithStats.filter(h => h.shouldShowToday)
    const completedToday = habitsForToday.filter(h => h.isCompletedToday).length
    const totalHabitsForToday = habitsForToday.length

    // Calculate overall streaks and completion rate
    const allCurrentStreaks = habitsWithStats.map(h => h.currentStreak)
    const allLongestStreaks = habitsWithStats.map(h => h.longestStreak)
    const overallCurrentStreak = allCurrentStreaks.length > 0 ? Math.max(...allCurrentStreaks) : 0
    const overallLongestStreak = allLongestStreaks.length > 0 ? Math.max(...allLongestStreaks) : 0

    // Calculate total completions
    const totalCompletions = await prisma.habitCompletion.count({
      where: { userId: user.id },
    })

    // Calculate overall completion rate
    const overallCompletionRate = totalHabitsForToday > 0 ? Math.round((completedToday / totalHabitsForToday) * 100) : 0

    const stats = {
      totalHabits,
      completedToday,
      totalHabitsForToday,
      currentStreak: overallCurrentStreak,
      longestStreak: overallLongestStreak,
      completionRate: overallCompletionRate,
      totalCompletions,
    }

    // Get recent activity (last 10 completions)
    const recentActivity = await prisma.habitCompletion.findMany({
      where: { userId: user.id },
      include: {
        habit: {
          include: {
            category: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
      take: 10,
    })

    // Get weekly data for charts
    const weeklyData = []
    for (let i = 6; i >= 0; i--) {
      const date = getDaysAgo(i)
      const endDate = new Date(date)
      endDate.setHours(23, 59, 59, 999)
      
      const dayOfWeek = getDayOfWeek(date)
      const habitsForDay = habits.filter(h => h.targetDays.includes(dayOfWeek))
      const completionsForDay = await prisma.habitCompletion.count({
        where: {
          userId: user.id,
          date: {
            gte: date,
            lte: endDate,
          },
        },
      })

      weeklyData.push({
        date: date.toISOString().split('T')[0],
        completed: completionsForDay,
        total: habitsForDay.length,
      })
    }

    return NextResponse.json({
      habits: habitsWithStats,
      stats,
      recentActivity,
      weeklyData,
    })
  } catch (error) {
    console.error('Error fetching dashboard data:', error)
    return NextResponse.json(
      { message: 'Internal server error' },
      { status: 500 }
    )
  }
}
