
export const dynamic = "force-dynamic";

import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { prisma } from '@/lib/db'

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession()
    
    if (!session?.user?.email) {
      return NextResponse.json({ message: 'Unauthorized' }, { status: 401 })
    }

    const user = await prisma.user.findUnique({
      where: { email: session.user.email },
    })

    if (!user) {
      return NextResponse.json({ message: 'User not found' }, { status: 404 })
    }

    const { action } = await request.json()

    if (!['accept', 'reject'].includes(action)) {
      return NextResponse.json(
        { message: 'Invalid action. Use "accept" or "reject"' },
        { status: 400 }
      )
    }

    const friendRequest = await prisma.friendRequest.findFirst({
      where: {
        id: params.id,
        receiverId: user.id,
        status: 'pending',
      },
    })

    if (!friendRequest) {
      return NextResponse.json(
        { message: 'Friend request not found' },
        { status: 404 }
      )
    }

    if (action === 'accept') {
      // Create friendship and update request status
      await prisma.$transaction([
        prisma.friendship.create({
          data: {
            user1Id: friendRequest.requesterId,
            user2Id: friendRequest.receiverId,
          },
        }),
        prisma.friendRequest.update({
          where: { id: params.id },
          data: { status: 'accepted' },
        }),
      ])

      return NextResponse.json({ message: 'Friend request accepted' })
    } else {
      // Reject the request
      await prisma.friendRequest.update({
        where: { id: params.id },
        data: { status: 'rejected' },
      })

      return NextResponse.json({ message: 'Friend request rejected' })
    }
  } catch (error) {
    console.error('Error updating friend request:', error)
    return NextResponse.json(
      { message: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession()
    
    if (!session?.user?.email) {
      return NextResponse.json({ message: 'Unauthorized' }, { status: 401 })
    }

    const user = await prisma.user.findUnique({
      where: { email: session.user.email },
    })

    if (!user) {
      return NextResponse.json({ message: 'User not found' }, { status: 404 })
    }

    const friendRequest = await prisma.friendRequest.findFirst({
      where: {
        id: params.id,
        requesterId: user.id,
        status: 'pending',
      },
    })

    if (!friendRequest) {
      return NextResponse.json(
        { message: 'Friend request not found' },
        { status: 404 }
      )
    }

    await prisma.friendRequest.delete({
      where: { id: params.id },
    })

    return NextResponse.json({ message: 'Friend request cancelled' })
  } catch (error) {
    console.error('Error cancelling friend request:', error)
    return NextResponse.json(
      { message: 'Internal server error' },
      { status: 500 }
    )
  }
}
