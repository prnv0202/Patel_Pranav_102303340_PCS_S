
export const dynamic = "force-dynamic";

import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { prisma } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession()
    
    if (!session?.user?.email) {
      return NextResponse.json({ message: 'Unauthorized' }, { status: 401 })
    }

    const user = await prisma.user.findUnique({
      where: { email: session.user.email },
    })

    if (!user) {
      return NextResponse.json({ message: 'User not found' }, { status: 404 })
    }

    // Get all friendships where user is either user1 or user2
    const friendships = await prisma.friendship.findMany({
      where: {
        OR: [
          { user1Id: user.id },
          { user2Id: user.id },
        ],
      },
      include: {
        user1: {
          select: {
            id: true,
            name: true,
            email: true,
            image: true,
            publicProfile: true,
          },
        },
        user2: {
          select: {
            id: true,
            name: true,
            email: true,
            image: true,
            publicProfile: true,
          },
        },
      },
    })

    // Transform to get the friend (the other user in each friendship)
    const friends = friendships.map(friendship => {
      const friend = friendship.user1Id === user.id ? friendship.user2 : friendship.user1
      return {
        id: friendship.id,
        friend,
        createdAt: friendship.createdAt,
      }
    })

    return NextResponse.json(friends)
  } catch (error) {
    console.error('Error fetching friends:', error)
    return NextResponse.json(
      { message: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession()
    
    if (!session?.user?.email) {
      return NextResponse.json({ message: 'Unauthorized' }, { status: 401 })
    }

    const user = await prisma.user.findUnique({
      where: { email: session.user.email },
    })

    if (!user) {
      return NextResponse.json({ message: 'User not found' }, { status: 404 })
    }

    const { friendEmail } = await request.json()

    if (!friendEmail) {
      return NextResponse.json(
        { message: 'Friend email is required' },
        { status: 400 }
      )
    }

    if (friendEmail === user.email) {
      return NextResponse.json(
        { message: 'Cannot send friend request to yourself' },
        { status: 400 }
      )
    }

    const friendUser = await prisma.user.findUnique({
      where: { email: friendEmail },
    })

    if (!friendUser) {
      return NextResponse.json(
        { message: 'User not found' },
        { status: 404 }
      )
    }

    // Check if friendship already exists
    const existingFriendship = await prisma.friendship.findFirst({
      where: {
        OR: [
          { user1Id: user.id, user2Id: friendUser.id },
          { user1Id: friendUser.id, user2Id: user.id },
        ],
      },
    })

    if (existingFriendship) {
      return NextResponse.json(
        { message: 'You are already friends with this user' },
        { status: 400 }
      )
    }

    // Check if friend request already exists
    const existingRequest = await prisma.friendRequest.findFirst({
      where: {
        OR: [
          { requesterId: user.id, receiverId: friendUser.id },
          { requesterId: friendUser.id, receiverId: user.id },
        ],
        status: 'pending',
      },
    })

    if (existingRequest) {
      return NextResponse.json(
        { message: 'Friend request already exists' },
        { status: 400 }
      )
    }

    const friendRequest = await prisma.friendRequest.create({
      data: {
        requesterId: user.id,
        receiverId: friendUser.id,
      },
      include: {
        requester: {
          select: {
            id: true,
            name: true,
            email: true,
            image: true,
          },
        },
        receiver: {
          select: {
            id: true,
            name: true,
            email: true,
            image: true,
          },
        },
      },
    })

    return NextResponse.json(friendRequest, { status: 201 })
  } catch (error) {
    console.error('Error sending friend request:', error)
    return NextResponse.json(
      { message: 'Internal server error' },
      { status: 500 }
    )
  }
}
