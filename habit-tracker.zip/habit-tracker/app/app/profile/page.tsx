
import { getServerSession } from 'next-auth'
import { redirect } from 'next/navigation'
import { ProfileClient } from './profile-client'

export default async function ProfilePage() {
  const session = await getServerSession()

  if (!session) {
    redirect('/')
  }

  return <ProfileClient />
}
