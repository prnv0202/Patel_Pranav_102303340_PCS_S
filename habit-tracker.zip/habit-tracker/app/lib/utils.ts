
import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatDate(date: Date): string {
  return new Intl.DateTimeFormat('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  }).format(date)
}

export function formatDateShort(date: Date): string {
  return new Intl.DateTimeFormat('en-US', {
    month: 'short',
    day: 'numeric',
  }).format(date)
}

export function isToday(date: Date): boolean {
  const today = new Date()
  return date.toDateString() === today.toDateString()
}

export function getStartOfDay(date: Date = new Date()): Date {
  const startOfDay = new Date(date)
  startOfDay.setHours(0, 0, 0, 0)
  return startOfDay
}

export function getEndOfDay(date: Date = new Date()): Date {
  const endOfDay = new Date(date)
  endOfDay.setHours(23, 59, 59, 999)
  return endOfDay
}

export function getDaysAgo(days: number): Date {
  const date = new Date()
  date.setDate(date.getDate() - days)
  return getStartOfDay(date)
}

export function getDayOfWeek(date: Date): string {
  const days = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday']
  return days[date.getDay()]
}

export function calculateStreak(completions: Date[]): number {
  if (completions.length === 0) return 0
  
  const sortedDates = completions
    .map(date => getStartOfDay(date))
    .sort((a, b) => b.getTime() - a.getTime())
  
  let streak = 0
  let currentDate = getStartOfDay(new Date())
  
  for (const completionDate of sortedDates) {
    if (completionDate.getTime() === currentDate.getTime()) {
      streak++
      currentDate.setDate(currentDate.getDate() - 1)
    } else if (completionDate.getTime() < currentDate.getTime()) {
      // Gap found, streak is broken
      break
    }
  }
  
  return streak
}

export function calculateLongestStreak(completions: Date[]): number {
  if (completions.length === 0) return 0
  
  const sortedDates = completions
    .map(date => getStartOfDay(date))
    .sort((a, b) => a.getTime() - b.getTime())
  
  let longestStreak = 0
  let currentStreak = 1
  
  for (let i = 1; i < sortedDates.length; i++) {
    const prevDate = sortedDates[i - 1]
    const currentDate = sortedDates[i]
    
    // Check if dates are consecutive
    const timeDiff = currentDate.getTime() - prevDate.getTime()
    const dayDiff = timeDiff / (1000 * 60 * 60 * 24)
    
    if (dayDiff === 1) {
      currentStreak++
    } else {
      longestStreak = Math.max(longestStreak, currentStreak)
      currentStreak = 1
    }
  }
  
  return Math.max(longestStreak, currentStreak)
}

export function calculateCompletionRate(completions: Date[], createdAt: Date): number {
  const now = new Date()
  const daysSinceCreation = Math.floor((now.getTime() - createdAt.getTime()) / (1000 * 60 * 60 * 24)) + 1
  return Math.round((completions.length / daysSinceCreation) * 100)
}

export function getWeeklyData(completions: Date[]): { date: string; completed: number }[] {
  const weeklyData = []
  const today = new Date()
  
  for (let i = 6; i >= 0; i--) {
    const date = new Date(today)
    date.setDate(today.getDate() - i)
    
    const completionsOnDate = completions.filter(completion => 
      getStartOfDay(completion).getTime() === getStartOfDay(date).getTime()
    ).length
    
    weeklyData.push({
      date: formatDateShort(date),
      completed: completionsOnDate,
    })
  }
  
  return weeklyData
}

export function getCategoryColorClass(categoryName: string): string {
  const categoryMap: { [key: string]: string } = {
    'Health': 'category-health',
    'Learning': 'category-learning',
    'Productivity': 'category-productivity',
    'Fitness': 'category-fitness',
    'Mindfulness': 'category-mindfulness',
    'Social': 'category-social',
    'Creative': 'category-creative',
    'Other': 'category-other',
  }
  
  return categoryMap[categoryName] || 'category-other'
}

export function shouldShowHabitToday(targetDays: string[]): boolean {
  const today = getDayOfWeek(new Date())
  return targetDays.includes(today)
}

export function getGreeting(): string {
  const hour = new Date().getHours()
  
  if (hour < 12) {
    return "Good morning"
  } else if (hour < 17) {
    return "Good afternoon"
  } else {
    return "Good evening"
  }
}

export function pluralize(count: number, singular: string, plural?: string): string {
  if (count === 1) {
    return `${count} ${singular}`
  }
  return `${count} ${plural || singular + 's'}`
}

export function debounce<T extends (...args: any[]) => void>(
  func: T,
  delay: number
): (...args: Parameters<T>) => void {
  let timeoutId: NodeJS.Timeout
  return (...args: Parameters<T>) => {
    clearTimeout(timeoutId)
    timeoutId = setTimeout(() => func.apply(null, args), delay)
  }
}

export function generateId(): string {
  return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15)
}

export function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  return emailRegex.test(email)
}

export function validatePassword(password: string): { isValid: boolean; message: string } {
  if (password.length < 6) {
    return { isValid: false, message: 'Password must be at least 6 characters long' }
  }
  
  if (!/[A-Za-z]/.test(password)) {
    return { isValid: false, message: 'Password must contain at least one letter' }
  }
  
  if (!/[0-9]/.test(password)) {
    return { isValid: false, message: 'Password must contain at least one number' }
  }
  
  return { isValid: true, message: '' }
}
