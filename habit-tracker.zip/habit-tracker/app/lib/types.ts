
export interface User {
  id: string
  name: string | null
  email: string
  emailVerified: Date | null
  image: string | null
  createdAt: Date
  updatedAt: Date
  notificationsEnabled: boolean
  reminderTime: string | null
  publicProfile: boolean
}

export interface Category {
  id: string
  name: string
  color: string
  icon: string
  description: string | null
  createdAt: Date
}

export interface Habit {
  id: string
  title: string
  description: string | null
  userId: string
  categoryId: string
  targetDays: string[]
  isActive: boolean
  createdAt: Date
  updatedAt: Date
  user?: User
  category?: Category
  completions?: HabitCompletion[]
  _count?: {
    completions: number
  }
}

export interface HabitCompletion {
  id: string
  habitId: string
  userId: string
  date: Date
  notes: string | null
  createdAt: Date
  habit?: Habit
  user?: User
}

export interface FriendRequest {
  id: string
  requesterId: string
  receiverId: string
  status: 'pending' | 'accepted' | 'rejected'
  createdAt: Date
  updatedAt: Date
  requester?: User
  receiver?: User
}

export interface Friendship {
  id: string
  user1Id: string
  user2Id: string
  createdAt: Date
  user1?: User
  user2?: User
}

export interface HabitStats {
  totalHabits: number
  completedToday: number
  totalHabitsForToday: number
  currentStreak: number
  longestStreak: number
  completionRate: number
  totalCompletions: number
}

export interface HabitWithStats extends Habit {
  currentStreak: number
  longestStreak: number
  completionRate: number
  isCompletedToday: boolean
  shouldShowToday: boolean
  totalCompletions: number
}

export interface DashboardData {
  habits: HabitWithStats[]
  stats: HabitStats
  recentActivity: (HabitCompletion & {
    habit: {
      title: string
      category: {
        name: string
        icon: string
        color: string
      }
    }
  })[]
  weeklyData: {
    date: string
    completed: number
    total: number
  }[]
}

export interface CreateHabitData {
  title: string
  description?: string
  categoryId: string
  targetDays: string[]
}

export interface UpdateHabitData {
  title?: string
  description?: string
  categoryId?: string
  targetDays?: string[]
  isActive?: boolean
}

export interface HabitFormData {
  title: string
  description: string
  categoryId: string
  targetDays: string[]
}

export const DEFAULT_CATEGORIES = [
  {
    name: 'Health',
    color: '#22c55e',
    icon: 'Heart',
    description: 'Physical and mental health habits'
  },
  {
    name: 'Learning',
    color: '#3b82f6',
    icon: 'BookOpen',
    description: 'Educational and skill development habits'
  },
  {
    name: 'Productivity',
    color: '#8b5cf6',
    icon: 'Target',
    description: 'Work and productivity habits'
  },
  {
    name: 'Fitness',
    color: '#f97316',
    icon: 'Dumbbell',
    description: 'Exercise and physical activity habits'
  },
  {
    name: 'Mindfulness',
    color: '#ec4899',
    icon: 'Brain',
    description: 'Meditation and mindfulness habits'
  },
  {
    name: 'Social',
    color: '#eab308',
    icon: 'Users',
    description: 'Social and relationship habits'
  },
  {
    name: 'Creative',
    color: '#6366f1',
    icon: 'Palette',
    description: 'Creative and artistic habits'
  },
  {
    name: 'Other',
    color: '#6b7280',
    icon: 'Plus',
    description: 'Other miscellaneous habits'
  }
]

export const DAYS_OF_WEEK = [
  { value: 'monday', label: 'Monday' },
  { value: 'tuesday', label: 'Tuesday' },
  { value: 'wednesday', label: 'Wednesday' },
  { value: 'thursday', label: 'Thursday' },
  { value: 'friday', label: 'Friday' },
  { value: 'saturday', label: 'Saturday' },
  { value: 'sunday', label: 'Sunday' }
]
