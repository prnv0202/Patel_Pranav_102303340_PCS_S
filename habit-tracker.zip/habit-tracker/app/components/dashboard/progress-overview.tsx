
'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Tooltip } from 'recharts'
import { BarChart3 } from 'lucide-react'

interface ProgressOverviewProps {
  weeklyData: {
    date: string
    completed: number
    total: number
  }[]
}

export function ProgressOverview({ weeklyData }: ProgressOverviewProps) {
  const chartData = weeklyData.map(item => ({
    ...item,
    completionRate: item.total > 0 ? Math.round((item.completed / item.total) * 100) : 0,
    displayDate: new Date(item.date).toLocaleDateString('en', { weekday: 'short' })
  }))

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <BarChart3 className="h-5 w-5 text-primary" />
          <span>Weekly Progress</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData} margin={{ top: 5, right: 5, left: 5, bottom: 5 }}>
              <XAxis 
                dataKey="displayDate" 
                tickLine={false}
                tick={{ fontSize: 10 }}
                axisLine={false}
              />
              <YAxis 
                tickLine={false}
                tick={{ fontSize: 10 }}
                axisLine={false}
                label={{ 
                  value: 'Completed', 
                  angle: -90, 
                  position: 'insideLeft',
                  style: { textAnchor: 'middle', fontSize: 11 }
                }}
              />
              <Tooltip 
                content={({ active, payload, label }) => {
                  if (active && payload && payload.length) {
                    const data = payload[0].payload
                    return (
                      <div className="bg-background border border-border rounded-lg p-3 shadow-lg">
                        <p className="font-medium">{label}</p>
                        <p className="text-sm text-muted-foreground">
                          {data.completed} of {data.total} habits completed
                        </p>
                        <p className="text-sm text-primary">
                          {data.completionRate}% completion rate
                        </p>
                      </div>
                    )
                  }
                  return null
                }}
              />
              <Bar 
                dataKey="completed" 
                fill="hsl(var(--primary))"
                radius={[2, 2, 0, 0]}
              />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  )
}
