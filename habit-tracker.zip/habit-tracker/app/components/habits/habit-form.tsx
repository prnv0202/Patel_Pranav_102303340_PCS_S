
'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Checkbox } from '@/components/ui/checkbox'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { useToast } from '@/hooks/use-toast'
import { Category, Habit, DAYS_OF_WEEK } from '@/lib/types'
import { getCategoryColorClass } from '@/lib/utils'
import { Save, X } from 'lucide-react'

interface HabitFormProps {
  habit?: Habit
  onSuccess: () => void
  onCancel: () => void
}

export function HabitForm({ habit, onSuccess, onCancel }: HabitFormProps) {
  const [title, setTitle] = useState(habit?.title || '')
  const [description, setDescription] = useState(habit?.description || '')
  const [categoryId, setCategoryId] = useState(habit?.categoryId || '')
  const [targetDays, setTargetDays] = useState<string[]>(habit?.targetDays || [])
  const [categories, setCategories] = useState<Category[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [isFetchingCategories, setIsFetchingCategories] = useState(true)
  const { toast } = useToast()

  useEffect(() => {
    fetchCategories()
  }, [])

  const fetchCategories = async () => {
    try {
      const response = await fetch('/api/categories')
      if (response.ok) {
        const data = await response.json()
        setCategories(data)
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to load categories',
        variant: 'destructive',
      })
    } finally {
      setIsFetchingCategories(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!title.trim()) {
      toast({
        title: 'Error',
        description: 'Please enter a habit title',
        variant: 'destructive',
      })
      return
    }

    if (!categoryId) {
      toast({
        title: 'Error',
        description: 'Please select a category',
        variant: 'destructive',
      })
      return
    }

    if (targetDays.length === 0) {
      toast({
        title: 'Error',
        description: 'Please select at least one day',
        variant: 'destructive',
      })
      return
    }

    setIsLoading(true)

    try {
      const url = habit ? `/api/habits/${habit.id}` : '/api/habits'
      const method = habit ? 'PUT' : 'POST'

      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          title: title.trim(),
          description: description.trim() || null,
          categoryId,
          targetDays,
        }),
      })

      if (response.ok) {
        toast({
          title: habit ? 'Habit updated' : 'Habit created',
          description: habit 
            ? `"${title}" has been updated successfully` 
            : `"${title}" has been created successfully`,
        })
        onSuccess()
      } else {
        const error = await response.json()
        throw new Error(error.message || 'Failed to save habit')
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: error instanceof Error ? error.message : 'Failed to save habit',
        variant: 'destructive',
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleDayToggle = (day: string) => {
    setTargetDays(prev => 
      prev.includes(day)
        ? prev.filter(d => d !== day)
        : [...prev, day]
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>
          {habit ? 'Edit Habit' : 'Create New Habit'}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="title">Habit Title *</Label>
            <Input
              id="title"
              type="text"
              placeholder="e.g., Read for 30 minutes"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              placeholder="Optional description or notes about this habit"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={3}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="category">Category *</Label>
            <Select value={categoryId} onValueChange={setCategoryId} disabled={isFetchingCategories}>
              <SelectTrigger>
                <SelectValue placeholder={isFetchingCategories ? "Loading categories..." : "Select a category"} />
              </SelectTrigger>
              <SelectContent>
                {categories.map((category) => (
                  <SelectItem key={category.id} value={category.id}>
                    <div className="flex items-center space-x-2">
                      <span className={`w-3 h-3 rounded-full`} style={{ backgroundColor: category.color }}></span>
                      <span>{category.name}</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-3">
            <Label>Target Days *</Label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {DAYS_OF_WEEK.map((day) => (
                <div key={day.value} className="flex items-center space-x-2">
                  <Checkbox
                    id={day.value}
                    checked={targetDays.includes(day.value)}
                    onCheckedChange={() => handleDayToggle(day.value)}
                  />
                  <Label
                    htmlFor={day.value}
                    className="text-sm font-normal cursor-pointer"
                  >
                    {day.label}
                  </Label>
                </div>
              ))}
            </div>
          </div>

          <div className="flex items-center space-x-3 pt-4">
            <Button type="submit" disabled={isLoading} className="flex items-center space-x-2">
              {isLoading ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                  <span>{habit ? 'Updating...' : 'Creating...'}</span>
                </>
              ) : (
                <>
                  <Save className="h-4 w-4" />
                  <span>{habit ? 'Update Habit' : 'Create Habit'}</span>
                </>
              )}
            </Button>
            <Button type="button" variant="outline" onClick={onCancel}>
              <X className="h-4 w-4 mr-2" />
              Cancel
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}
