
'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { HabitWithStats } from '@/lib/types'
import { getCategoryColorClass } from '@/lib/utils'
import { useToast } from '@/hooks/use-toast'
import { 
  CheckCircle, 
  Circle, 
  Flame, 
  Edit, 
  Trash2, 
  Calendar,
  MoreHorizontal 
} from 'lucide-react'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { HabitForm } from './habit-form'
import { motion } from 'framer-motion'

interface HabitCardProps {
  habit: HabitWithStats
  onUpdate: () => void
  showNotScheduled?: boolean
}

export function HabitCard({ habit, onUpdate, showNotScheduled = false }: HabitCardProps) {
  const [isCompleting, setIsCompleting] = useState(false)
  const [isEditing, setIsEditing] = useState(false)
  const [isDeleting, setIsDeleting] = useState(false)
  const { toast } = useToast()

  const handleToggleCompletion = async () => {
    setIsCompleting(true)
    try {
      const url = `/api/habits/${habit.id}/complete`
      const method = habit.isCompletedToday ? 'DELETE' : 'POST'
      
      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ date: new Date().toISOString() }),
      })

      if (response.ok) {
        toast({
          title: habit.isCompletedToday ? 'Habit unchecked' : 'Great job!',
          description: habit.isCompletedToday 
            ? `Removed completion for "${habit.title}"` 
            : `You completed "${habit.title}"`,
        })
        onUpdate()
      } else {
        throw new Error('Failed to update habit')
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to update habit completion',
        variant: 'destructive',
      })
    } finally {
      setIsCompleting(false)
    }
  }

  const handleDelete = async () => {
    setIsDeleting(true)
    try {
      const response = await fetch(`/api/habits/${habit.id}`, {
        method: 'DELETE',
      })

      if (response.ok) {
        toast({
          title: 'Habit deleted',
          description: `"${habit.title}" has been deleted`,
        })
        onUpdate()
      } else {
        throw new Error('Failed to delete habit')
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to delete habit',
        variant: 'destructive',
      })
    } finally {
      setIsDeleting(false)
    }
  }

  const handleEditSuccess = () => {
    setIsEditing(false)
    onUpdate()
  }

  if (isEditing) {
    return (
      <Card>
        <CardContent className="p-6">
          <HabitForm
            habit={habit}
            onSuccess={handleEditSuccess}
            onCancel={() => setIsEditing(false)}
          />
        </CardContent>
      </Card>
    )
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="habit-card"
    >
      <Card className="hover:shadow-md transition-all duration-200">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4 flex-1">
              {/* Completion Button */}
              <Button
                variant="ghost"
                size="icon"
                onClick={handleToggleCompletion}
                disabled={isCompleting || showNotScheduled}
                className={`w-8 h-8 rounded-full ${
                  habit.isCompletedToday
                    ? 'text-green-600 hover:text-green-700'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                {habit.isCompletedToday ? (
                  <CheckCircle className="h-6 w-6" />
                ) : (
                  <Circle className="h-6 w-6" />
                )}
              </Button>

              {/* Habit Info */}
              <div className="flex-1 min-w-0">
                <h3 className={`font-semibold text-foreground ${
                  habit.isCompletedToday ? 'line-through opacity-70' : ''
                }`}>
                  {habit.title}
                </h3>
                {habit.description && (
                  <p className="text-sm text-muted-foreground mt-1">
                    {habit.description}
                  </p>
                )}
                <div className="flex items-center space-x-3 mt-2">
                  {/* Category */}
                  <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${getCategoryColorClass(habit.category?.name || 'Other')}`}>
                    {habit.category?.name || 'Other'}
                  </span>

                  {/* Streak */}
                  {habit.currentStreak > 0 && (
                    <div className="flex items-center space-x-1 text-orange-600">
                      <Flame className="h-3 w-3" />
                      <span className="text-xs font-medium">
                        {habit.currentStreak} day{habit.currentStreak !== 1 ? 's' : ''}
                      </span>
                    </div>
                  )}

                  {/* Not scheduled indicator */}
                  {showNotScheduled && (
                    <div className="flex items-center space-x-1 text-muted-foreground">
                      <Calendar className="h-3 w-3" />
                      <span className="text-xs">Not scheduled today</span>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Actions Menu */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon">
                  <MoreHorizontal className="h-4 w-4" />
                  <span className="sr-only">More options</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => setIsEditing(true)}>
                  <Edit className="mr-2 h-4 w-4" />
                  Edit
                </DropdownMenuItem>
                <DropdownMenuItem 
                  onClick={handleDelete}
                  disabled={isDeleting}
                  className="text-red-600"
                >
                  <Trash2 className="mr-2 h-4 w-4" />
                  Delete
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  )
}
