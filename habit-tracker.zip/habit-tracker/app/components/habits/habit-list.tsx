
'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { HabitCard } from './habit-card'
import { HabitForm } from './habit-form'
import { HabitWithStats } from '@/lib/types'
import { Plus, Target } from 'lucide-react'

interface HabitListProps {
  habits: HabitWithStats[]
  onHabitUpdate: () => void
}

export function HabitList({ habits, onHabitUpdate }: HabitListProps) {
  const [showForm, setShowForm] = useState(false)

  const todayHabits = habits.filter(habit => habit.shouldShowToday)
  const otherHabits = habits.filter(habit => !habit.shouldShowToday)

  const handleHabitCreated = () => {
    setShowForm(false)
    onHabitUpdate()
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center space-x-2">
              <Target className="h-5 w-5 text-primary" />
              <span>Today's Habits</span>
            </CardTitle>
            <Button
              onClick={() => setShowForm(!showForm)}
              size="sm"
              className="flex items-center space-x-2"
            >
              <Plus className="h-4 w-4" />
              <span>Add Habit</span>
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {showForm && (
            <div className="mb-6">
              <HabitForm
                onSuccess={handleHabitCreated}
                onCancel={() => setShowForm(false)}
              />
            </div>
          )}

          {todayHabits.length === 0 && !showForm ? (
            <div className="text-center py-8">
              <div className="text-muted-foreground text-sm mb-4">
                No habits scheduled for today. Create your first habit to get started!
              </div>
              <Button
                onClick={() => setShowForm(true)}
                variant="outline"
                className="flex items-center space-x-2"
              >
                <Plus className="h-4 w-4" />
                <span>Create First Habit</span>
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {todayHabits.map((habit) => (
                <HabitCard
                  key={habit.id}
                  habit={habit}
                  onUpdate={onHabitUpdate}
                />
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {otherHabits.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Other Habits</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {otherHabits.map((habit) => (
                <HabitCard
                  key={habit.id}
                  habit={habit}
                  onUpdate={onHabitUpdate}
                  showNotScheduled
                />
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
